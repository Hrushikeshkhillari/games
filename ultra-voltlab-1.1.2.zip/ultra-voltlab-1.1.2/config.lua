-- The sum of all the 3 values should not increase 111. 
-- Example 1:{1, 10, 50} so, 1+10+50=61 is valid
-- Example 2:{1, 10, 50} so, 5+10+100=115 is invalid
-- timer = 10
iconValues = {1, 10, 50}
